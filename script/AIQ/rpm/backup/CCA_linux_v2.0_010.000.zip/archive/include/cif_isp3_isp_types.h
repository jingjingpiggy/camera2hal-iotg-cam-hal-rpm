/*
 * INTEL CONFIDENTIAL
 * Copyright (c) 2014 Intel Corporation
 * All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel
 * Corporation or its suppliers and licensors. The Material may contain trade
 * secrets and proprietary and confidential information of Intel Corporation
 * and its suppliers and licensors, and is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may be
 * used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials, either expressly, by implication, inducement,
 * estoppel or otherwise. Any license under such intellectual property rights
 * must be express and approved by Intel in writing.
 *
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intels
 * suppliers or licensors in any way.
 */

#ifndef _CIF_ISP_TYPES_H
#define _CIF_ISP_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

#define CIFISP_AWB_MAX_GRID				4800
#define CIFISP_HIST_BIN_N_MAX			128
#define CIFISP_AFM_MAX_GRID				1200
#define CIFISP_AE_MEAN_MAX				25
#define CIFISP_GAMMA_OUT_TBL_SIZE		259
#define CIFISP_DEGAMMA_TBL_SIZE			257
#define CIFISP_LSC_GRAD_TBL_SIZE		16
#define CIFISP_LSC_SIZE_TBL_SIZE		16
#define CIFISP_LSC_DATA_TBL_SIZE		561
#define CIFISP_TONE_MAP_TABLE_SIZE		257
#define CIFISP_BNR_LUT_SIZE				33
#define CIFISP_AFM_FILTER_SIZE			33
#define CIFISP_AFM_COEFFS_SIZE			9
#define CIFISP_SKINTONE_TABLE_SIZE		33
#define CIFISP_BNR_TABLE_SIZE			33

enum cifisp_histogram_mode {
	CIFISP_HISTOGRAM_MODE_DISABLE         = 0,
	CIFISP_HISTOGRAM_MODE_RGB_COMBINED    = 1,
	CIFISP_HISTOGRAM_MODE_R_HISTOGRAM     = 2,
	CIFISP_HISTOGRAM_MODE_G_HISTOGRAM     = 3,
	CIFISP_HISTOGRAM_MODE_B_HISTOGRAM     = 4,
	CIFISP_HISTOGRAM_MODE_Y_HISTOGRAM     = 5
};

enum cifisp_exp_ctrl_autostop {
	CIFISP_EXP_CTRL_AUTOSTOP_0 = 0,
	CIFISP_EXP_CTRL_AUTOSTOP_1 = 1
};

struct cifisp_window {
	unsigned short h_offs;
	unsigned short v_offs;
	unsigned short h_size;
	unsigned short v_size;
};

enum cifisp_awb_mode_type {
	CIFISP_AWB_MODE_MANUAL  = 0,
	CIFISP_AWB_MODE_RGB     = 1,
	CIFISP_AWB_MODE_YCBCR   = 2
};


/*! bad pixel element attribute*/
enum cifisp_bp_type {
	CIFISP_BP_TYPE_HOT,      /* hot pixel */
	CIFISP_BP_TYPE_DEAD    /* dead pixel */
};


/*! possible bad pixel correction type*/
enum cifisp_bp_corr_type {
	CIFISP_BP_CORR_TYPE_DIRECT /* direct detection and correction*/
};

/*! possible bad pixel replace approach*/
enum cifisp_bp_corr_rep {
	CIFISP_BP_CORR_REP_NB,      /* nearest neighbour approach*/
	CIFISP_BP_CORR_REP_LIN      /* simple bilinear interpolation approach*/
};

/*! possible bad pixel correction mode*/
enum  cifisp_bp_corr_mode {
	CIF_ISP_BP_CORR_HOT_EN,         /* hot pixel correction*/
	CIF_ISP_BP_CORR_DEAD_EN,     /* dead pixel correction*/
	CIF_ISP_BP_CORR_HOT_DEAD_EN  /* hot and dead pixel correction*/
};

/*! possible bad pixel correction mode*/
enum  cifisp_bls_mode {
	CIF_ISP_BLS_FIXED,
	CIF_ISP_BLS_AUTO
};

enum cifisp_stat_type {
	CIFISP_STAT_AWB,
	CIFISP_STAT_EXP,
	CIFISP_STAT_AFM,
	CIFISP_STAT_HIST
};

enum cifisp_bls_win_enable {
	ISP_BLS_CTRL_WINDOW_ENABLE_0 = 0,
	ISP_BLS_CTRL_WINDOW_ENABLE_1 = 1,
	ISP_BLS_CTRL_WINDOW_ENABLE_2 = 2,
	ISP_BLS_CTRL_WINDOW_ENABLE_3 = 3
};

enum cifisp_colorfx {
	CIFISP_COLORFX_NONE = 0,
	CIFISP_COLORFX_BW = 1,
	CIFISP_COLORFX_SEPIA = 2,
	CIFISP_COLORFX_NEGATIVE = 3,
	CIFISP_COLORFX_EMBOSS = 4,
	CIFISP_COLORFX_SKETCH = 5,
	CIFISP_COLORFX_SKY_BLUE = 6,
	CIFISP_COLORFX_GRASS_GREEN = 7,
	CIFISP_COLORFX_SKIN_WHITEN = 8,
	CIFISP_COLORFX_VIVID = 9,
	CIFISP_COLORFX_AQUA = 10,
	CIFISP_COLORFX_ART_FREEZE = 11,
	CIFISP_COLORFX_SILHOUETTE = 12,
	CIFISP_COLORFX_SOLARIZATION = 13,
	CIFISP_COLORFX_ANTIQUE = 14,
	CIFISP_COLORFX_SET_CBCR = 15
};

struct cifisp_ie_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	enum cifisp_colorfx effect;
	unsigned short color_sel;
	/*3x3 Matrix Coefficients for Emboss Effect 1*/
	unsigned short eff_mat_1;
	/*3x3 Matrix Coefficients for Emboss Effect 2*/
	unsigned short eff_mat_2;
	/*3x3 Matrix Coefficients for Emboss 3/Sketch 1*/
	unsigned short eff_mat_3;
	/*3x3 Matrix Coefficients for Sketch Effect 2*/
	unsigned short eff_mat_4;
	/*3x3 Matrix Coefficients for Sketch Effect 3*/
	unsigned short eff_mat_5;
	/*Chrominance increment values of tint (used for sepia effect)*/
	unsigned short eff_tint;
};

struct cifisp_awb_meas_yc {
	unsigned int cnt;
	unsigned char mean_y;
	unsigned char mean_cb;
	unsigned char mean_cr;
};

struct cifisp_awb_meas_bayer {
	unsigned int cnt;
	unsigned short mean_r;
	unsigned short mean_b;
	unsigned short mean_gr;
	unsigned short mean_gb;
};

struct cifisp_awb_stat {
	union {
		struct cifisp_awb_meas_bayer bayer[CIFISP_AWB_MAX_GRID];
		struct cifisp_awb_meas_yc yc[CIFISP_AWB_MAX_GRID];
	} awb_mean;
};

struct cifisp_hist_stat {
	unsigned short hist_bins[CIFISP_HIST_BIN_N_MAX];
};

/*! BLS mean measured values*/
struct cifisp_bls_meas_val {
	/*! Mean measured value for Bayer pattern position A.*/
	unsigned short meas_a;
	/*! Mean measured value for Bayer pattern position B.*/
	unsigned short meas_b;
	/*! Mean measured value for Bayer pattern position C.*/
	unsigned short meas_c;
	/*! Mean measured value for Bayer pattern position D.*/
	unsigned short meas_d;
};

struct cifisp_ae_stat {
	unsigned char exp_mean[CIFISP_AE_MEAN_MAX];
	struct cifisp_bls_meas_val bls_val; /*available wit exposure results*/
};

struct cifisp_af_meas_val {
	unsigned int afm_result1;
	unsigned int afm_result2;
	unsigned int afm_lum;
};

struct cifisp_af_stat {
	struct cifisp_af_meas_val window[CIFISP_AFM_MAX_GRID];
};

union cifisp_stat {
	struct cifisp_awb_stat awb;
	struct cifisp_ae_stat ae;
	struct cifisp_af_stat af;
	struct cifisp_hist_stat hist;
};

struct cifisp_stat_buffer {
	enum cifisp_stat_type meas_type;
	union cifisp_stat params;
};

/*! configuration for detection of bad pixel block*/
struct cifisp_bp_detection_config {
	/*Enables the turbulence based gradient adjustment for hot pixels*/
	unsigned char bp_hot_turbulence_adj_en;
	/*Enables the turbulence based gradient adjustment for dead pixels*/
	unsigned char bp_dead_turbulence_adj_en;
	/*Enables/disables the sign sensitivity for hot gradient evaluation*/
	unsigned char bp_dev_hot_sign_sens;
	/*Enables/disables the sign sensitivity for dead gradient evaluation.*/
	unsigned char bp_dev_dead_sign_sens;
	/* Divider (shift) configuration for the calculated turbulence value
	 *  used by hot pixel detection*/
	unsigned char   bp_hot_turbulence_shift;
	/*Divider (shift) configuration for the calculated turbulence value
	 *  used by dead pixel detection.*/
	unsigned char   bp_dead_turbulence_shift;
	/*The amount of gradients - exceeding the threshold - which triggers
	 *  a hot pixel detection.*/
	unsigned char   bp_dev_hot_grad_trig_lvl;
	/*The amount of gradients - exceeding the threshold - which triggers
	 *  a dead pixel detection .*/
	unsigned char   bp_dev_dead_grad_trig_lvl;
};

struct cifisp_bp_direct {
	unsigned short abs_hot_thres;  /* Absolute hot pixel threshold*/
	unsigned short abs_dead_thres; /* Absolute dead pixel threshold*/
	unsigned short dev_hot_thres;  /* Hot Pixel deviation Threshold*/
	unsigned short dev_dead_thres; /* Dead Pixel deviation Threshold*/
	unsigned char w0;
	unsigned char w1;
	unsigned short th0;
	unsigned int offset;
};

/*! configuration for correction of bad pixel block*/
struct cifisp_bp_correction_config {
	enum cifisp_bp_corr_type corr_type; /* bad pixel correction type*/
	enum cifisp_bp_corr_rep corr_rep; /* replace approach*/
	enum cifisp_bp_corr_mode corr_mode;   /* bad pixel correction mode*/
	struct cifisp_bp_direct bp_corr_direct;
};

/* Configuration used by bad pixel detection & correction */
struct cifisp_bpc_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	struct cifisp_bp_correction_config corr_config;
	struct cifisp_bp_detection_config det_config;
};

/*! BLS fixed subtraction values. The values will be subtracted from the sensor
 *  values. Therefore a negative value means addition instead of subtraction!*/
struct cifisp_bls_fixed_config {
	/*! Fixed (signed!) subtraction value for Bayer pattern position A.*/
	signed short fixed_a;
	/*! Fixed (signed!) subtraction value for Bayer pattern position B.*/
	signed short fixed_b;
	/*! Fixed (signed!) subtraction value for Bayer pattern position C.*/
	signed short fixed_c;
	/*! Fixed (signed!) subtraction value for Bayer pattern position D.*/
	signed short fixed_d;
};

struct cifisp_bls_meas_config {
	struct cifisp_window bls_window1;
	struct cifisp_window bls_window2;
	unsigned char bls_samples;
	unsigned char window_enable;
};

/* Configuration used by black level subtraction */
struct cifisp_bls_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	/*! Automatic mode activated means that the measured values
	 * are subtracted.Otherwise the fixed subtraction
	 * values will be subtracted.*/
	enum cifisp_bls_mode mode;
	union {
		struct cifisp_bls_fixed_config fixed;
		struct cifisp_bls_meas_config meas;
	} config;
};

/* Configuration used by sensor degamma */
struct cifisp_sdg_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned short gamma_gr[CIFISP_DEGAMMA_TBL_SIZE];
	unsigned short gamma_gb[CIFISP_DEGAMMA_TBL_SIZE];
	unsigned short gamma_b[CIFISP_DEGAMMA_TBL_SIZE];
	unsigned short gamma_r[CIFISP_DEGAMMA_TBL_SIZE];
};

/* Configuration used by Lens shading correction */
struct cifisp_lsc_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned int r_data_tbl[CIFISP_LSC_DATA_TBL_SIZE];
	unsigned int gr_data_tbl[CIFISP_LSC_DATA_TBL_SIZE];
	unsigned int gb_data_tbl[CIFISP_LSC_DATA_TBL_SIZE];
	unsigned int b_data_tbl[CIFISP_LSC_DATA_TBL_SIZE];
	unsigned int x_grad_tbl[CIFISP_LSC_GRAD_TBL_SIZE];
	unsigned int y_grad_tbl[CIFISP_LSC_GRAD_TBL_SIZE];
	unsigned int x_size_tbl[CIFISP_LSC_SIZE_TBL_SIZE];
	unsigned int y_size_tbl[CIFISP_LSC_SIZE_TBL_SIZE];
	unsigned short config_width;
	unsigned short config_height;
};

struct cifisp_meas_grid {
	unsigned short h_offs;
	unsigned short v_offs;
	unsigned short h_dim;
	unsigned short v_dim;
	unsigned short h_dist;
	unsigned short v_dist;
	unsigned short h_size;
	unsigned short v_size;
};

struct cifisp_awb_yc_meas_config {
	/*! only pixels values < max_y contribute to awb measurement
	 * (set to 0 to disable this feature)*/
	unsigned char    max_y;
	/*! only pixels values > min_y contribute to awb measurement*/
	unsigned char    min_y;
	/*! Chrominance sum maximum value, only consider pixels with Cb+Cr
	 *  smaller than threshold for awb measurements*/
	unsigned char    max_csum;
	/*! Chrominance minimum value, only consider pixels with Cb/Cr
	 *  each greater than threshold value for awb measurements*/
	unsigned char    min_c;
	/*! reference Cr value for AWB regulation, target for AWB*/
	unsigned char    awb_ref_cr;
	/*! reference Cb value for AWB regulation, target for AWB*/
	unsigned char    awb_ref_cb;
	unsigned char enable_ymax_cmp;
	/*before(1) or after(0) white balance gains adjustment*/
};

struct cifisp_awb_bayer_meas_config {
	unsigned short   gb_sat;
	unsigned short   gr_sat;
	unsigned short   b_sat;
	unsigned short   r_sat;
	unsigned char rgb_meas_pnt;
	unsigned char awbm_before_lsc;
	unsigned char rgb_include_sat_pix;
};

/* Configuration used by auto white balance */
struct cifisp_awb_meas_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	enum cifisp_awb_mode_type awb_mode;
	union {
		struct cifisp_awb_yc_meas_config yc;
		struct cifisp_awb_bayer_meas_config bayer;
	} config;
	/*! number of frames - 1 used for mean value calculation
	 *  (ucFrames=0 means 1 Frame)*/
	unsigned char    frames;
	struct cifisp_meas_grid grid;
};

struct cifisp_awb_gain_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned short  gain_red;
	unsigned short  gain_green_r;
	unsigned short  gain_blue;
	unsigned short  gain_green_b;
};

/*Configuration used by BNR in cif3.1 */
struct cifisp_bnr_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned int bnr_weight;
	unsigned int bnr_offs_sq[2];
	unsigned int bnr_antishading;
	unsigned int bnr_wb_gain;
	unsigned int bnr_coeffs;
	unsigned short bnr_table[CIFISP_BNR_TABLE_SIZE];
	unsigned short bnr_offs[2];
	unsigned char bnr_norm_shift;
};

struct cifisp_gd_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned char gd_enable;
	unsigned char clip;
	unsigned char red_coeff;
	unsigned char green_coeff;
	unsigned char blue_coeff;
	unsigned char antishading;
	unsigned char cent2perif_ratio;
	unsigned char pix_support;
	unsigned short dark_offset;
};

/* Configuration used by ISP filtering */
struct cifisp_flt_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned int flt_mask_sharp0;
	unsigned int flt_mask_sharp1;
	unsigned int flt_mask_diag;
	unsigned int flt_mask_blur_max;
	unsigned int flt_mask_blur;
	unsigned int flt_mask_lin;
	unsigned int flt_mask_orth;
	unsigned int flt_mask_v_diag;
	unsigned int flt_mask_h_diag;
	unsigned int flt_lum_weight;
	unsigned short flt_blur_th0;
	unsigned short flt_blur_th1;
	unsigned short flt_sharp0_th;
	unsigned short flt_sharp1_th;
	unsigned short flt_cas_enable;
	unsigned short flt_cas_lowlevel;
	unsigned short flt_cas_th0;
	unsigned short flt_cas_th1;
	unsigned short flt_cas_inverse;
	unsigned char demosaic_th;
	unsigned char flt_chrom_h_mode;
	unsigned char flt_chrom_v_mode;
	unsigned char flt_diag_sharp_mode;
	unsigned char flt_mode;
};

/* Configuration used by Cross Talk correction */
struct cifisp_ctk_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned short coeff0;
	unsigned short coeff1;
	unsigned short coeff2;
	unsigned short coeff3;
	unsigned short coeff4;
	unsigned short coeff5;
	unsigned short coeff6;
	unsigned short coeff7;
	unsigned short coeff8;
	/* offset for the crosstalk correction matrix */
	unsigned short ct_offset_r;
	unsigned short ct_offset_g;
	unsigned short ct_offset_b;
};

/* Configuration used by Gamma Out correction */
struct cifisp_goc_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned int gamma_rgb[CIFISP_GAMMA_OUT_TBL_SIZE];
};

/* Multi Axis Color Control Structures - MACC */
struct cifisp_macc_coeff {
	/*! Macc coefficients. Refer to equation 23 in datasheet */
	unsigned int coeff0;
	/*! Macc coefficients. Refer to equation 23 in datasheet */
	unsigned int coeff1;
};

struct cifisp_macc_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	struct cifisp_macc_coeff seg0; /*!< Macc coefficients for segment */
	struct cifisp_macc_coeff seg1;
	struct cifisp_macc_coeff seg2;
	struct cifisp_macc_coeff seg3;
	struct cifisp_macc_coeff seg4;
	struct cifisp_macc_coeff seg5;
	struct cifisp_macc_coeff seg6;
	struct cifisp_macc_coeff seg7;
	struct cifisp_macc_coeff seg8;
	struct cifisp_macc_coeff seg9;
	struct cifisp_macc_coeff seg10;
	struct cifisp_macc_coeff seg11;
	struct cifisp_macc_coeff seg12;
	struct cifisp_macc_coeff seg13;
	struct cifisp_macc_coeff seg14;
	struct cifisp_macc_coeff seg15;
};

/* CCM (Color Correction) */
struct cifisp_cproc_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned char c_out_range;
	unsigned char y_in_range;
	unsigned char y_out_range;
	unsigned char contrast;
	unsigned char brightness;
	unsigned char sat;
	unsigned char hue;
};

struct cifisp_tmap_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned short tmap_y[CIFISP_TONE_MAP_TABLE_SIZE];
	unsigned short tmap_c[CIFISP_TONE_MAP_TABLE_SIZE];
};

/* Configuration used by Histogram */
struct cifisp_hst_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned char histogram_predivider;
	enum cifisp_histogram_mode mode;
	struct cifisp_window meas_window;
};

/* Configuration used by Auto Exposure Control */
struct cifisp_aem_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	enum cifisp_exp_ctrl_autostop autostop;
	struct cifisp_window meas_window;
};

/* YC FLT */
struct cifisp_ycflt_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	unsigned int ctrl;
	unsigned int ss_ctrl;
	unsigned int ss_fac;
	unsigned int ss_offs;
	unsigned int chr_nr_ctrl;
	unsigned int lum_eenr_edge_gain;
	unsigned int lum_eenr_corner_gain;
	unsigned int lum_eenr_fc_crop_pos;
	unsigned int lum_eenr_fc_crop_neg;
	unsigned int lum_eenr_fc_gain_pos;
	unsigned int lum_eenr_fc_gain_neg;
	unsigned int lum_nr_ctrl;
	unsigned int lum_eenr_fc_coring_pos;
	unsigned int lum_eenr_fc_coring_neg;
	unsigned int skin_tone_y_lut[CIFISP_SKINTONE_TABLE_SIZE];
	unsigned int skin_tone_cb_lut[CIFISP_SKINTONE_TABLE_SIZE];
	unsigned int skin_tone_cr_lut[CIFISP_SKINTONE_TABLE_SIZE];
	unsigned int skin_tone_s_lut[CIFISP_SKINTONE_TABLE_SIZE];
	unsigned int skin_tone_norm_offs;
};

struct cifisp_afm_config {
	unsigned char on; /* true if block shall be enabled, false if switched off*/
	struct cifisp_meas_grid grid;
	unsigned int afm_result1_thres;
	unsigned int afm_result2_thres;
	unsigned char afm_result1_rshift;
	unsigned char afm_result2_rshift;
	unsigned char afm_lum_rshift;
	unsigned char afm_filter_coeffs_matx[CIFISP_AFM_FILTER_SIZE];
	unsigned char afm_filter_coeffs_maty[CIFISP_AFM_FILTER_SIZE];
	unsigned char afm_bayer2y_coeffs[CIFISP_AFM_COEFFS_SIZE];
};

#ifdef __cplusplus
}
#endif

#endif
